<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Website STT Nurul Fikri</title>

    <style>
        table{
            text-align: center;
        }
    </style>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css')?>" >
    <!-- Icon -->
    <link rel="stylesheet" href="<?php echo base_url('assets/fonts/line-icons.css')?>">
    <!-- Slicknav -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/slicknav.css')?>">
    <!-- Owl carousel -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/owl.carousel.min.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/owl.theme.css')?>">
    
    <link rel="stylesheet" href="<?php echo base_url('assets/css/magnific-popup.css')?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/nivo-lightbox.css')?>">
    <!-- Animate -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/animate.css')?>">
    <!-- Main Style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/main.css')?>">
    <!-- Responsive Style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/responsive.css')?>">

  </head>
  <body>

    <!-- Header Area wrapper Starts -->
    <header id="header-wrap">
      <!-- Navbar Start -->
      <nav class="navbar navbar-expand-md bg-inverse fixed-top scrolling-navbar">
        <div class="container">
          <!-- Brand and toggle get grouped for better mobile display -->
          <a href="index.html" class="navbar-brand"><img src="<?php echo base_url('assets/img/logonf.png')?>" width="150" height="150" alt=""></a>       
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
            <i class="lni-menu"></i>
          </button>
          <div class="collapse navbar-collapse" id="navbarCollapse">
            <ul class="navbar-nav mr-auto w-100 justify-content-end clearfix">
              <li class="nav-item active">
                <a class="nav-link" href="#hero-area">
                  Home
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#tentang">
                  Tentang
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#visimisi">
                  Visi & Misi
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#tujuan">
                  Tujuan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#jurusan">
                  Jurusan
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#mahasiswa">
                  Mahasiswa
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#dosen">
                  Dosen
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#prodi">
                  Prodi
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#contact">
                  Contact
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="login">
                  Login
                </a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- Navbar End -->

      <!-- Hero Area Start -->
      <div id="hero-area" class="hero-area-bg">
        <div class="container">
          <div class="row">
            <div class="col-md-12 col-sm-12">
              <div class="contents text-center">
                <h1 class="head-title wow fadeInUp">SEKOLAH TINGGI TEKNOLOGI <br> TERPADU NURUL FIKRI</h1>
                <div class="header-button wow fadeInUp" data-wow-delay="0.3s">
                  <a href="login" class="btn btn-common">Login</a>
                </div>
              </div>
              <div class="img-thumb text-center wow fadeInUp" data-wow-delay="0.6s">
                <img class="img-fluid" src="<?php echo base_url('assets/img/NFimg.png')?>" width="500" height="400" alt="">
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- Hero Area End -->

    </header>
    <!-- Header Area wrapper End -->

    <!-- Feature Section Start -->
    <div id="tentang">
      <div class="container-fluid">
        <div class="row">
          <div class="col-lg-6 col-md-12 col-sm-12">
            <div class="text-wrapper">
              <div>
                <h2 class="title-hl wow fadeInLeft" data-wow-delay="0.3s">Tentang <br> STT NURUL FIKRI</h2>
                <!-- <p class="mb-4">A digital studio specialising in User Experience & eCommerce, we combine innovation with digital craftsmanship to help brands fulfill their potential.</p> -->
                <a href="#" class="btn btn-common">More About Us</a>
              </div>
            </div>
          </div>
          <div class="col-lg-6 col-md-12 col-sm-12 padding-none feature-bg">
            <div class="feature-thumb">
              <div class="feature-item wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="700ms">
                <div class="icon">
                  <i class="lni-medall-alt"></i>
                </div>
                <div class="feature-content">
                  <h3>STT NF</h3>
                  <p>Sekolah Tinggi Teknologi Terpadu Nurul Fikri (populer disebut STT-NF) merupakan perguruan tinggi yang memadukan keilmuan praktis di bidang teknologi informasi dengan pengembangan kepribadian islami, kompeten dan berkarakter.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Feature Section End -->

    <!-- Services Section Start -->
    <section id="visimisi" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Visi dan Misi STT NF</h2>
        </div>
        <div class="row">
          <!-- Services item -->
          <div class="col-md-8 col-lg-12 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.3s">
              <div class="icon">
                <i class="lni-pencil"></i>
              </div>
              <div class="services-content">
                <h3><a href="#">Visi STT NF</a></h3>
                <p>Pada tahun 2045 menjadi sekolah tinggi yang unggul di Indonesia, berbudaya inovasi, berjiwa teknopreneur, dan berkarakter religius.</p>
              </div>
            </div>
          </div>
    
          <!-- Services item -->
          <div class="col-md-8 col-lg-12 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.3s">
              <div class="icon">
                <i class="lni-pencil"></i>
              </div>
              <div class="services-content">
                <h3><a href="#">Misi STT NF</a></h3>
                <p>1. Menyelenggarakan pendidikan tinggi berkualitasyang mengembangkan jiwa kepemimpinan dan teknopreneurship berlandaskan iman dan takwa.</p>
                <p>2. Melaksanakan penelitian yang inovatif dan berorientasi pada pengembangan teknologi masa depan.</p>
                <p>3. Menyelenggarakan pengabdian kepada masyarakat dengan memanfaatkan teknologi tepat guna.</p>
                <p>4. Membangun lingkungan akademik yang kondusif bagi terwujudnya kebebasan akademik, otonomi keilmuan, dan budaya inovasi.</p>
              </div>
            </div>
          </div>

    <section id="tujuan" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">TUJUAN</h2>
        </div>
        <div class="row">
           <!-- Services item -->
           <div class="col-md-8 col-lg-12 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.3s">
              <div class="icon">
                <i class="lni-pencil"></i>
              </div>
              <div class="services-content">
                <p>1. Menghasilkan sarjana yang kompeten, profesional, berakhlak mulia, sehingga mampu berkompetisi di dunia kerja dan dunia usaha.</p>
                <p>2. Menghasilkan karya-karya ilmiah di bidang teknologi informasi, berwawasan masa depan yang inovatif dan bercirikan keterbukaan (openness) seperti open source, open standard dan open access/content, sehingga lebih bermanfaat bagi bangsa Indonesia dan diakui secara internasional.</p>
                <p>3. Menerapkan ilmu pengetahuan dan teknologi tepat guna bagi masyarakat dengan melibatkan sivitas akademika.</p>
                <p>4. Menciptakan kultur akademik yang inovatif, kompetitif dan kondusif untuk mewujudkan institusi pendidikan tinggi yang unggul dan terkemuka.</p>
              </div>
            </div>
          </div>
    
    <!-- Services Section End -->

    <!-- Services Section Start -->
    <section id="jurusan" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">JURUSAN</h2>
          <p>Jurusan yang ada di STT NF meliputi 3 jurusan, diantaranya :</p>
        </div>
        <div class="row">
          <!-- Services item -->
          <div class="col-md-6 col-lg-4 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.9s">
              <div class="icon">
                <i class="lni-cog"></i>
              </div>
              <div class="services-content">
                <h3><a href="#">Teknik Informatika</a></h3>
                <p>Kompetensi lulusan program studi Teknik Informatika (TI): mampu memahami pengembangan perangkat lunak, database, jaringan/infrastruktur teknologi informasi untuk berbagai kebutuhan komputasi terkini dan masa depan, dengan dua peminatan Rekayasa Perangkat Lunak (Software Engineering) dan Infrastruktur Teknologi Informasi (IT Infrastructure).</p>
              </div>
            </div>
          </div>
          
          <!-- Services item -->
          <div class="col-md-6 col-lg-4 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="1.5s">
              <div class="icon">
                <i class="lni-layers"></i>
              </div>
              <div class="services-content">
                <h3><a href="#">Sistem Informasi</a></h3>
                <p>Kompetensi lulusan program studi Sistem Informasi (SI): mampu memahami manajemen organisasi dan bisnis; mampu merancang, menerapkan, dan mengelola sistem informasi untuk bisnis dan organisasi besar, dengan dua peminatan Desain Komunikasi Visual (Visual Communication Design), Tata Kelola Teknologi Informasi (IT Governance), dan Sistem Informasi Enterprise (Enterprise Information System).</p>
              </div>
            </div>
          </div>
          <!-- Services item -->
          <div class="col-md-6 col-lg-4 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.6s">
              <div class="icon">
                <i class="lni-briefcase"></i>
              </div>
              <div class="services-content">
                <h3><a href="#">Bisnis Digital</a></h3>
                <p>Kompetensi lulusan program studi Bisnis Digital (DG): menguasai konsep teknologi informasi, khususnya di bidang teori komputasi, jaringan komputer, teknologi web, teknologi mobile, sistem informasi, dan pengelolaan data; menguasai konsep dasar bisnis, proses bisnis, pemasaran, supply chain, manajemen produksi, dan manajemen keuangan.</p>
              </div>
            </div>
          </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Services Section End -->

    
  <!-- Services Section Start -->
  <section id="mahasiswa" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Daftar Mahasiswa</h2>
        </div>
        <div class="row">
          <!-- Services item -->
          <div class="col-md-8 col-lg-12 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.3s">
              <div class="services-content">
              <table class="table table-bordered">
            <thead class="table-secondary">
            <tr>
                    <th scope="col">No</th>
                    <th scope="col">NIM</th>
                    <th scope="col">Nama Mahasiswa</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Tempat Lahir</th>
                    <th scope="col">Tanggal Lahir</th>
                    <th scope="col">IPK</th>
                    <th scope="col">Program Studi</th>
                    
                </tr>
            </thead>
            <tbody>
                <?php
                    $nomor = 1;
                    foreach($list_mahasiswa as $obj){
                ?>

                <tr>
                    <td><?= $nomor ?></th>
                    <td><?= $obj -> nim ?></td>
                    <td><?= $obj -> nama ?></td>
                    <td><?= $obj-> gender ?></td>
                    <td><?= $obj -> tmp_lahir ?></td>
                    <td><?= $obj -> tgl_lahir ?></td>
                    <td><?= $obj-> ipk ?></td>
                    <td><?= $obj->prodi_kode?></td>  
                </tr>
                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
              </div>
            </div>
          </div>
  </session>       
    
    <!-- Services Section End -->

    <!-- Services Section Start -->
  <section id="dosen" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Daftar Dosen</h2>
        </div>
        <div class="row">
          <!-- Services item -->
          <div class="col-md-8 col-lg-12 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.3s">
              <div class="services-content">
              <table class="table table-bordered">
            <thead class="table-secondary">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">NIDN</th>
                    <th scope="col">Nama Dosen</th>
                    <th scope="col">Gender</th>
                    <th scope="col">Tanggal Lahir</th>
                    <th scope="col">Tempat Lahir</th>
                    <th scope="col">Pendidikan</th>
                    <th scope="col">Kode Prodi</th>
                </tr>
            </thead>
            <tbody>

                <?php
                    $nomor = 1;
                    foreach($list_dosen as $dosen){
                ?>

                <tr>
                    <td><?= $nomor ?></td>
                    <td><?= $dosen->nidn ?></td>
                    <td><?= $dosen->nama_dosen ?></td>
                    <td><?= $dosen->gender ?></td>
                    <td><?= $dosen->tgl_lahir ?></td>
                    <td><?= $dosen->tmp_lahir ?></td>
                    <td><?= $dosen->pendidikan_akhir ?></td>
                    <td><?= $dosen->prodi_kode ?></td>
                </tr>
                
                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
              </div>
            </div>
          </div>
  </session>       
    
    <!-- Services Section End -->

    <!-- Services Section Start -->
  <section id="prodi" class="section-padding bg-gray">
      <div class="container">
        <div class="section-header text-center">
          <h2 class="section-title wow fadeInDown" data-wow-delay="0.3s">Daftar Program Studi</h2>
        </div>
        <div class="row">
          <!-- Services item -->
          <div class="col-md-8 col-lg-12 col-xs-12">
            <div class="services-item wow fadeInRight" data-wow-delay="0.3s">
              <div class="services-content">
              <table class="table table-bordered">
            <thead class="table-secondary">
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Kode</th>
                    <th scope="col">Nama Prodi</th>
                    <th scope="col">Kaprodi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $nomor = 1;
                    foreach($list_prodi as $prodi){
                ?>

                <tr>
                    <td><?= $nomor ?></th>
                    <td><?= $prodi->kode ?></td>
                    <td><?= $prodi->nama ?></td>
                    <td><?= $prodi->kaprodi ?></td>
                </tr>
                
                <?php
                    $nomor++;
                    }
                ?>
            </tbody>
        </table>
              </div>
            </div>
          </div>
  </session>       
    
    <!-- Services Section End -->
  
    <!-- Testimonial Section Start -->
    <br>
    <h2>Info Kampus</h2>
    <section id="testimonial" class="testimonial section-padding">
      <div class="overlay"></div>
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-lg-7 col-md-12 col-sm-12 col-xs-12">
            <div id="testimonials" class="owl-carousel wow fadeInUp" data-wow-delay="1.2s">
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="assets/img/testimonial/img1.jpg" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="#">Beasiswa Sarjana</a></h2>
                  </div>
                  <div class="content">
                    <p class="description">STT NF bekerja sama dengan berbagai institusi dan perorangan memberikan beasiswa untuk mahasiswa dari keluarga dhuafa dan mahasiswa berprestasi. Pemberi beasiswa itu antara lain dari pemerintah pusat melalui Kopertis IV, pemerintah daerah, perusahaan swasta, BUMN, BUMD, lembaga ZIS, perorangan, dan mitra lain Yayasan Profesi Terpadu Nurul Fikri.</p>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="assets/img/testimonial/img2.jpg" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="#">Pembangunan Karakter dan Klub Mahasiswa</a></h2>
                  </div>
                  <div class="content">
                    <p class="description">Mahasiswa STT NF dibimbing para dosen untuk membangun karakternya agar menjadi mahasiswa yang siap menghadapi persaingan global dengan karakter mulia. Pendidikan soft skill diberikan melalui perkuliahan (ada mata kuliah kepribadian di tiap semester) dan di luar kuliah, antara lain tentang kerja sama tim, keterampilan berkomunikasi, keterampilan berorganisasi, kepemimpinan, kewirausahaan/technopreneurship, dan sebagainya. Salah satu pelatihan soft skill untuk mahasiswa STT NF adalah School of Thinking </p>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="assets/img/testimonial/img3.jpg" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="#">Sejarah</a></h2>
                  </div>
                  <div class="content">
                    <p class="description">STT NF diawali dari sebuah divisi pendidikan komputer Yayasan Nurul Fikri pada 1994 dengan nama Nurul Fikri Computer & Statistics (NCS), disebut juga NF Computer.[1] Pada 1998 NF Computer mulai menyelenggarakan pelatihan Linux dan Open Source. Pada awal 2000-an NCS berubah nama menjadi Lembaga Pendidikan Komputer Nurul Fikri (LPKNF), yang kemudian berganti nama menjadi Lembaga Pendidikan dan Pengembangan Profesi Terpadu Nurul Fikri (LP3TNF). Pada 13 Agustus 2012, STT-NF resmi berdiri dengan SK Menteri Pendidikan dan Kebudayaan No. 269/E/O/2012. </p>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimonial-item">
                  <div class="img-thumb">
                    <img src="assets/img/testimonial/img4.png" alt="">
                  </div>
                  <div class="info">
                    <h2><a href="#">Mitra</a></h2>
                  </div>
                  <div class="content">
                    <p class="description">STT Nurul Fikri memiliki banyak mitra strategis yang kompeten dalam pengembangan penelitian teknologi informasi, karier, pemberi dana beasiswa, dan pengabdian kepada masyarakat. </p>
                  </div>
                </div>
              </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!-- Testimonial Section End -->


    <!-- Contact Section Start -->
    <section id="contact" class="section-padding">    
      <div class="container">
        <div class="row contact-form-area wow fadeInUp" data-wow-delay="0.4s">          
          <div class="col-md-6 col-lg-6 col-sm-12">
            <div class="contact-block">
              <form id="contactForm">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="text" class="form-control" id="name" name="name" placeholder="Name" required data-error="Please enter your name">
                      <div class="help-block with-errors"></div>
                    </div>                                 
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <input type="text" placeholder="Email" id="email" class="form-control" name="email" required data-error="Please enter your email">
                      <div class="help-block with-errors"></div>
                    </div> 
                  </div>
                   <div class="col-md-12">
                    <div class="form-group">
                      <input type="text" placeholder="Subject" id="msg_subject" class="form-control" required data-error="Please enter your subject">
                      <div class="help-block with-errors"></div>
                    </div>
                  </div>
                  <div class="col-md-12">
                    <div class="form-group"> 
                      <textarea class="form-control" id="message" placeholder="Your Message" rows="5" data-error="Write your message" required></textarea>
                      <div class="help-block with-errors"></div>
                    </div>
                    <div class="submit-button">
                      <button class="btn btn-common" id="form-submit" type="submit">Send Message</button>
                      <div id="msgSubmit" class="h3 text-center hidden"></div> 
                      <div class="clearfix"></div> 
                    </div>
                  </div>
                </div>            
              </form>
            </div>
          </div>
          <div class="col-md-6 col-lg-6 col-sm-12">
            <div class="contact-right-area wow fadeIn">
              <div class="contact-title">
                <h1>We're a friendly bunch..</h1>
                <p>We create projects for companies and startups with a passion for quality</p>
              </div>
              <h2>Contact Us</h2>
              <div class="contact-right">
                <div class="single-contact">
                  <div class="contact-icon">
                    <i class="lni-map-marker"></i>
                  </div>
                  <p>STT Terpadu Nurul Fikri
                    Kampus A: Jl. Situ Indah no.116, Cimanggis, Depok
                    Kampus B: Jl. Raya Lenteng Agung No.20, Jagakarsa</p>
                </div>
                <div class="single-contact">
                  <div class="contact-icon">
                    <i class="lni-envelope"></i>
                  </div>
                  <p><a href="#">Email:  info@nurulfikri.ac.id</a></p>
                </div>
                <div class="single-contact">
                  <div class="contact-icon">
                    <i class="lni-phone-handset"></i>
                  </div>
                  <p><a href="#">Phone:  021 - 786 3191</a></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> 
    </section>
    <!-- Contact Section End -->
  
    

    <!-- Go to Top Link -->
    <a href="#" class="back-to-top">
    	<i class="lni-arrow-up"></i>
    </a>
    
    <!-- Preloader -->
    <div id="preloader">
      <div class="loader" id="loader-1"></div>
    </div>
    <!-- End Preloader -->
    
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="<?php echo base_url('assets/js/jquery-min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/popper.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/bootstrap.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/owl.carousel.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.mixitup.js')?>"></script>
    <script src="<?php echo base_url('assets/js/wow.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.nav.js')?>"></script>
    <script src="<?php echo base_url('assets/js/scrolling-nav.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.easing.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/jquery.counterup.min.js')?>"></script>  
    <script src="<?php echo base_url('assets/js/nivo-lightbox.js')?>"></script>     
    <script src="<?php echo base_url('assets/js/jquery.magnific-popup.min.js')?>"></script>     
    <script src="<?php echo base_url('assets/js/waypoints.min.js')?>"></script>   
    <script src="<?php echo base_url('assets/js/jquery.slicknav.js')?>"></script>
    <script src="<?php echo base_url('assets/js/main.js')?>"></script>
    <script src="<?php echo base_url('assets/js/form-validator.min.js')?>"></script>
    <script src="<?php echo base_url('assets/js/contact-form-script.min.js')?>"></script>
      
  </body>
</html>
