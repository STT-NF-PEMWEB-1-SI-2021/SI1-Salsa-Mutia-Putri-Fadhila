<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css"> 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
    h2{
        text-align:center;
    }
    button{
        width: 24.5cm;
    }
    h3{
        text-align:center;
    }
    table{
        font: size 13px;
    }
    .jumbotron{
        background-color: #FFFFFF;
    }
</style>

<div class="jumbotron">
    <h2>Kalkulator BMI</h2>
    
<div class="jumbotron">
<form method = "POST" action = "">
  <div class="form-group">
    <label for="nama">Nama Pasien</label> 
    <input id="nama" name="nama" type="text" class="form-control" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="kode">Kode Pasien</label> 
    <input id="kode" name="kode" type="text" class="form-control" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="tanggal">Tanggal Periksa</label> 
    <input id="tanggal" name="tanggal" placeholder="yyyy-mm-dd" type="text" class="form-control" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="gender">Gender</label> 
    <div>
      <select id="gender" name="gender" class="custom-select">
        <option value="Pilih Gender">~~ Pilih Gender ~~</option>
        <option value="L">Laki-laki</option>
        <option value="P">Perempuan</option>
      </select>
    </div>
  </div>
  <div class="form-group">
    <label for="berat">Berat Badan Pasien</label> 
    <input id="berat" name="berat" placeholder="(kg)" type="text" class="form-control" autocomplete="off">
  </div>
  <div class="form-group">
    <label for="tinggi">Tinggi Badan Pasien</label> 
    <input id="tinggi" name="tinggi" placeholder="(m)" type="text" class="form-control" autocomplete="off">
  </div> 
  <div class="form-group">
    <button name="submit" type="submit" class="btn btn-primary">Hitung</button>
  </div>
</form>

<!-- PHP ARRAY SESSION -->
<?php
require_once 'class_bmi.php';
require_once 'class_pasien.php';

error_reporting(0);
$nama = $_POST['nama'];
$kode = $_POST['kode'];
$tanggal = $_POST['tanggal'];
$gender = $_POST['gender'];
$berat = $_POST['berat'];
$tinggi = $_POST['tinggi'];

$nilai = new BMI ($berat, $tinggi);

$data1 = ['id'=>1, 'tgl_periksa'=>'2022-01-10','kode'=>'P001','nama'=>'Ahmad','gender'=>'L','berat'=>69.8,'tinggi'=>169,'Nilai_BMI'=>24.7,'Status_BMI'=>'Kelebihan Berat Badan'];
$data2 = ['id'=>2, 'tgl_periksa'=>'2022-01-10','kode'=>'P002','nama'=>'Rina','gender'=>'P','berat'=>55.3,'tinggi'=>165,'Nilai_BMI'=>20.3,'Status_BMI'=>'Normal(ideal)'];
$data3 = ['id'=>3, 'tgl_periksa'=>'2022-01-11','kode'=>'P003','nama'=>'Lutfi','gender'=>'L','berat'=>45.2,'tinggi'=>171,'Nilai_BMI'=>15.4,'Status_BMI'=>'Kekurangan Berat Badan'];
$data4 = ['id'=>4, 'tgl_periksa'=>$tanggal,'kode'=>$kode,'nama'=>$nama,'gender'=>$gender,'berat'=>$berat,'tinggi'=>$tinggi,'Nilai_BMI'=>$nilai->nilaiBMI(),'Status_BMI'=>$nilai->statusBMI()];
$ar_data = [$data1, $data2, $data3, $data4];
?>
<br><br>
<hr>
<h2>Index Hasil BMI</h2>
<br>

<table class="table">
  <thead class="thead-dark">
        <tr>
            <th>No</th>
            <th>Tanggal Periksa</th>
            <th>Kode pasien</th>
            <th>Nama Pasien</th>
            <th>Gender</th>
            <th>Berat(Kg)</th>
            <th>Tinggi(cm)</th>
            <th>Nilai BMI</th>
            <th>Status BMI</th>
        </tr>
    </thead>
    <tbody>

      <?php
        $nomor=1;
        foreach($ar_data as $data){
            echo'<tr>';
            echo '<td>'.$nomor.'</td>';
            echo '<td>'.$data['tgl_periksa'].'</td>';
            echo '<td>'.$data['kode'].'</td>';
            echo '<td>'.$data['nama'].'</td>';
            echo '<td>'.$data['gender'].'</td>';
            echo '<td>'.$data['berat'].'</td>';
            echo '<td>'.$data['tinggi'].'</td>';
            echo '<td>'.$data['Nilai_BMI'].'</td>';
            echo '<td>'.$data['Status_BMI'].'</td>';
            $nomor++;

        }
      ?>
    </tbody>
</table>

