<?php
require_once 'class_BMIPasien.php';

class BMI extends BMIpasien{
    public $berat;
    public $tinggi;
    
    public function __construct($berat,$tinggi){
        $this->berat = $berat;
        $this->tinggi = $tinggi;
    }

    function nilaiBMI(){
        $this->nilaiBMI =$this->berat / ($this->tinggi*$this->tinggi);
        return $this->nilaiBMI;
    }

    public function statusBMI(){
        if ($this->nilaiBMI < 18.5){
            return 'Kekurangan berat badan';
        }
        else if ($this->nilaiBMI >=18.5){
            return 'Normal';
        }
        else if ($this->nilaiBMI >=25.0){
            return 'Kelebihan berat badan';
        }
        else if ($this->nilaiBMI >= 30.0){
            return 'Kegemukan';
        }
    }
}
?>